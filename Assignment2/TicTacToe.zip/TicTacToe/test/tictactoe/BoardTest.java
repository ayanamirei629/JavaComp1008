/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Yingge Hu
 */
public class BoardTest {
    
    Board validBoard;
    public BoardTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        validBoard = new Board();
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getBoard method, of class Board.
     */
    @Test
    public void testGetBoard() {
        List<List<Integer>> expResult = new ArrayList<>();
        List<Integer> row = new ArrayList<>();
        row.add(0);
        row.add(0);
        row.add(0);
        expResult.add(row);
        expResult.add(row);
        expResult.add(row);
        List<List<Integer>> result = validBoard.getBoard();
        assertEquals(expResult, result);
    }

    /**
     * Test of nextStep method, of class Board.
     */
    @Test
    public void testNextStepPlayer() {
        List<List<Integer>> expResult = new ArrayList<>();
        List<Integer> row = new ArrayList<>();
        row.add(0);
        row.add(0);
        row.add(0);
        expResult.add(row);
        expResult.add(row);
        row = new ArrayList<>();
        row.add(1);
        row.add(0);
        row.add(0);
        expResult.add(row);
        validBoard.nextStep(2,0,"player");
        assertEquals(expResult, validBoard.getBoard());
         
    }

    /**
     * Test of validplayer method, of class Board.
     */
    @Test
    public void testValidplayer() {
        System.out.println("validplayer");
        String player = "";
        Board instance = new Board();
        instance.validplayer(player);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validRowAndCol method, of class Board.
     */
    @Test
    public void testValidRowAndCol() {
        System.out.println("validRowAndCol");
        int row = 0;
        int col = 0;
        Board instance = new Board();
        instance.validRowAndCol(row, col);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getValue method, of class Board.
     */
    @Test
    public void testGetValue() {
        System.out.println("getValue");
        int row = 0;
        int col = 0;
        Board instance = new Board();
        int expResult = 0;
        int result = instance.getValue(row, col);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkValues method, of class Board.
     */
    @Test
    public void testCheckValues() {
        System.out.println("checkValues");
        Board instance = new Board();
        List<Integer> expResult = null;
        List<Integer> result = instance.checkValues();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of allFilled method, of class Board.
     */
    @Test
    public void testAllFilled() {
        System.out.println("allFilled");
        Board instance = new Board();
        boolean expResult = false;
        boolean result = instance.allFilled();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of availablePos method, of class Board.
     */
    @Test
    public void testAvailablePos() {
        System.out.println("availablePos");
        Board instance = new Board();
        List<List<Integer>> expResult = null;
        List<List<Integer>> result = instance.availablePos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of newBoard method, of class Board.
     */
    @Test
    public void testNewBoard() {
        System.out.println("newBoard");
        Board instance = new Board();
        instance.newBoard();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
