/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author ayana
 */
public class ChallengerViewController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private ImageView imageView;

    @FXML
    private TextField firstName;

    @FXML
    private TextField lastName;

    @FXML
    private RadioButton maleBtn;
    
    @FXML
    private RadioButton femaleBtn;
    
    @FXML
    private TextField age;
    
    @FXML
    private Label error;
    
    ArrayList<Challenger> database = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    public void updateInfo()
    {
        if(!validation()){
            return;
        }
        Challenger newChallenger = new Challenger(firstName.getText(),lastName.getText(),getGender(),getAge());
        database.add(newChallenger);
        error.setText("challenger saved!");
    }
    
    public boolean validation(){
        String output ="";
        if(firstName.getText().isEmpty()){
            output += "first name, ";
        }
        if(lastName.getText().isEmpty()){
            output += "last name, ";
        }
        if(age.getText().isEmpty()){
            output += "age name, ";
        }
        if((!maleBtn.isSelected() && !femaleBtn.isSelected())||(maleBtn.isSelected() && femaleBtn.isSelected())){
            output += "gender, ";
        }
        if(!output.isEmpty()){
            output = output.substring(0, -2) + " is incorrect.";
            error.setText(output);
            return false;
        }
        return true;    
    }
    
    public String getGender(){
        if(maleBtn.isSelected()){
            return "male";
        }
        else{
            return "female";
        }
    }
    
    public int getAge(){
        return Integer.valueOf(age.getText());
    }
}
