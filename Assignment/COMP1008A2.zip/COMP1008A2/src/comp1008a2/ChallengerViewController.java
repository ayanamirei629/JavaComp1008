/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp1008a2;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author ayana
 */
public class ChallengerViewController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private ImageView imageView;

    @FXML
    private TextField firstName;

    @FXML
    private TextField lastName;
    
    @FXML
    private Slider slider;

    @FXML
    private RadioButton maleBtn;
    
    @FXML
    private RadioButton femaleBtn;
    
    @FXML
    private TextField age;
    
    @FXML
    private Label error;
    
    @FXML
    private Button save;
    
    private Image image;
    
    ArrayList<Challenger> database = new ArrayList<>();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
    @FXML
    public void updateInfo()
    {
        if(!validation()){
            return;
        }
        Challenger newChallenger = new Challenger(firstName.getText(),lastName.getText(),getGender(),getAge());
        database.add(newChallenger);
        error.setText("challenger saved!");
    }
    
    public boolean validation(){
        String output ="";
        if(firstName.getText().isEmpty()){
            output += "first name, ";
        }
        if(lastName.getText().isEmpty()){
            output += "last name, ";
        }
        if(age.getText().isEmpty()){
            output += "age name, ";
        }
        if(!maleBtn.isSelected() && !femaleBtn.isSelected()){
            output += "gender, ";
        }
        
        System.out.println(output);
        if(output.isEmpty()){
            return true; 
            
        } 
        else {
            output = output.substring(0, output.length()-2) + " is incorrect.";
            System.out.println(output);
            error.setText(output);
            return false;
        }
           
    }
    
    public String getGender(){
        if(maleBtn.isSelected()){
            return "male";
        }
        else{
            return "female";
        }
    }
    
    public void setMale(){
        femaleBtn.setSelected(false);
        setImage();
    }
    
    public void setFemale(){
        maleBtn.setSelected(false);
        setImage();
    }
    
    public int getAge(){
        return Integer.valueOf(age.getText());
    }
    
    @FXML
    private void setImage(){
        if(maleBtn.isSelected() || femaleBtn.isSelected()){
            String imageLocation = "./images/"+ getGender() + (int)Math.round(slider.getValue()) +".jpg";
            image = new Image(imageLocation);
            imageView.setImage(image);
        }
    }

    
}
